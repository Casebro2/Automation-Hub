package com.automationhub.data.database.dao

import androidx.room.*
import com.automationhub.data.database.entity.ProgressEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for progress tracking
 */
@Dao
interface ProgressDao {
    
    @Query("SELECT * FROM progress WHERE moduleId = :moduleId")
    fun getProgressForModule(moduleId: String): Flow<List<ProgressEntity>>
    
    @Query("SELECT * FROM progress WHERE lessonId = :lessonId")
    suspend fun getProgressForLesson(lessonId: String): ProgressEntity?
    
    @Query("SELECT * FROM progress WHERE projectId = :projectId")
    suspend fun getProgressForProject(projectId: String): ProgressEntity?
    
    @Query("SELECT * FROM progress WHERE isCompleted = 1")
    fun getCompletedItems(): Flow<List<ProgressEntity>>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgress(progress: ProgressEntity)
    
    @Update
    suspend fun updateProgress(progress: ProgressEntity)
    
    @Query("SELECT COUNT(*) FROM progress WHERE isCompleted = 1")
    suspend fun getCompletedCount(): Int
    
    @Query("SELECT COUNT(*) FROM progress")
    suspend fun getTotalCount(): Int
}

