package com.automationhub.data.model

data class Module(
    val id: String,
    val title: String,
    val description: String,
    val stage: String, // Beginner, Intermediate, Expert
    val lessons: List<Lesson>
)


