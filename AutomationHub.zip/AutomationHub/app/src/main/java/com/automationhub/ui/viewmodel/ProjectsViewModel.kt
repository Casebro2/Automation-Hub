package com.automationhub.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.automationhub.data.database.entity.ProgressEntity
import com.automationhub.data.model.Project
import com.automationhub.data.repository.AutomationHubRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * ViewModel for the Projects screen
 */
class ProjectsViewModel(private val repository: AutomationHubRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(ProjectsUiState())
    val uiState: StateFlow<ProjectsUiState> = _uiState.asStateFlow()

    init {
        loadProjects()
    }

    private fun loadProjects() {
        viewModelScope.launch {
            val projects = repository.getProjects()
            _uiState.value = _uiState.value.copy(
                projects = projects,
                isLoading = false
            )
        }
    }

    fun filterByDifficulty(difficulty: String) {
        val allProjects = repository.getProjects()
        val filteredProjects = if (difficulty == "All") {
            allProjects
        } else {
            allProjects.filter { it.difficulty == difficulty }
        }
        _uiState.value = _uiState.value.copy(
            projects = filteredProjects,
            selectedDifficulty = difficulty
        )
    }

    fun markProjectComplete(projectId: String) {
        viewModelScope.launch {
            val progress = ProgressEntity(
                id = UUID.randomUUID().toString(),
                moduleId = "", // Projects are standalone
                projectId = projectId,
                isCompleted = true,
                completionDate = System.currentTimeMillis(),
                progressPercentage = 100
            )
            repository.insertProgress(progress)
        }
    }
}

data class ProjectsUiState(
    val projects: List<Project> = emptyList(),
    val selectedDifficulty: String = "All",
    val isLoading: Boolean = true
)

