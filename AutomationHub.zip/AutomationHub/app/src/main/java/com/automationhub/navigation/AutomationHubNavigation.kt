package com.automationhub.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.automationhub.data.repository.AutomationHubRepository
import com.automationhub.ui.screen.*

/**
 * Navigation graph for the Automation Hub app
 */
@Composable
fun AutomationHubNavigation(
    navController: NavHostController,
    repository: AutomationHubRepository
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Onboarding.route
    ) {
        composable(Screen.Onboarding.route) {
            OnboardingScreen(
                onNavigateToDashboard = {
                    navController.navigate(Screen.Dashboard.route) {
                        popUpTo(Screen.Onboarding.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Dashboard.route) {
            DashboardScreen(
                repository = repository,
                onNavigateToModules = { navController.navigate(Screen.Modules.route) },
                onNavigateToProjects = { navController.navigate(Screen.Projects.route) }
            )
        }

        composable(Screen.Modules.route) {
            ModulesScreen(
                repository = repository,
                onNavigateToModule = { moduleId ->
                    navController.navigate(Screen.ModuleDetail.createRoute(moduleId))
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Screen.ModuleDetail.route) { backStackEntry ->
            val moduleId = backStackEntry.arguments?.getString("moduleId") ?: ""
            ModuleDetailScreen(
                moduleId = moduleId,
                repository = repository,
                onNavigateToLesson = { lessonId ->
                    navController.navigate(Screen.LessonDetail.createRoute(moduleId, lessonId))
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Screen.LessonDetail.route) { backStackEntry ->
            val moduleId = backStackEntry.arguments?.getString("moduleId") ?: ""
            val lessonId = backStackEntry.arguments?.getString("lessonId") ?: ""
            LessonDetailScreen(
                moduleId = moduleId,
                lessonId = lessonId,
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Projects.route) {
            ProjectsScreen(
                repository = repository,
                onNavigateToProject = { projectId ->
                    navController.navigate(Screen.ProjectDetail.createRoute(projectId))
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Screen.ProjectDetail.route) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getString("projectId") ?: ""
            ProjectDetailScreen(
                projectId = projectId,
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Calendar.route) {
            CalendarScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Notes.route) {
            NotesScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}

