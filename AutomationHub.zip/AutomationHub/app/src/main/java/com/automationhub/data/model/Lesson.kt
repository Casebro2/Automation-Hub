package com.automationhub.data.model

data class Lesson(
    val id: String,
    val title: String,
    val description: String,
    val content: String,
    val videoUrl: String? = null,
    val externalLinks: List<String> = emptyList(),
    val codeSnippets: List<CodeSnippet> = emptyList()
)

data class CodeSnippet(
    val language: String,
    val code: String,
    val description: String
)

