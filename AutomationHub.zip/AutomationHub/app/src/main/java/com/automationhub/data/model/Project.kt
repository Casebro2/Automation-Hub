package com.automationhub.data.model

data class Project(
    val id: String,
    val title: String,
    val description: String,
    val difficulty: String, // Easy, Medium, Hard
    val tools: List<String>, // n8n, Zapier, Python, etc.
    val tasks: List<String>,
    val estimatedTime: String
)

