package com.automationhub.data.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room entity for storing user notes per lesson
 */
@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey val id: String,
    val lessonId: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

