package com.automationhub.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.automationhub.data.database.entity.NoteEntity
import com.automationhub.data.database.entity.ProgressEntity
import com.automationhub.data.model.Lesson
import com.automationhub.data.repository.AutomationHubRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * ViewModel for the Lesson screen
 */
class LessonViewModel(private val repository: AutomationHubRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(LessonUiState())
    val uiState: StateFlow<LessonUiState> = _uiState.asStateFlow()

    fun loadLesson(moduleId: String, lessonId: String) {
        viewModelScope.launch {
            val module = repository.getModuleById(moduleId)
            val lesson = module?.lessons?.find { it.id == lessonId }
            val progress = repository.getProgressForLesson(lessonId)

            _uiState.value = _uiState.value.copy(
                lesson = lesson,
                isCompleted = progress?.isCompleted ?: false,
                isLoading = false
            )

            // Load notes for this lesson
            repository.getNotesForLesson(lessonId).collect { notes ->
                _uiState.value = _uiState.value.copy(notes = notes)
            }
        }
    }

    fun markLessonComplete(moduleId: String, lessonId: String) {
        viewModelScope.launch {
            val progress = ProgressEntity(
                id = UUID.randomUUID().toString(),
                moduleId = moduleId,
                lessonId = lessonId,
                isCompleted = true,
                completionDate = System.currentTimeMillis(),
                progressPercentage = 100
            )
            repository.insertProgress(progress)
            _uiState.value = _uiState.value.copy(isCompleted = true)
        }
    }

    fun addNote(lessonId: String, content: String) {
        viewModelScope.launch {
            val note = NoteEntity(
                id = UUID.randomUUID().toString(),
                lessonId = lessonId,
                content = content
            )
            repository.insertNote(note)
        }
    }

    fun updateNote(note: NoteEntity) {
        viewModelScope.launch {
            repository.updateNote(note)
        }
    }

    fun deleteNote(note: NoteEntity) {
        viewModelScope.launch {
            repository.deleteNote(note)
        }
    }
}

data class LessonUiState(
    val lesson: Lesson? = null,
    val notes: List<NoteEntity> = emptyList(),
    val isCompleted: Boolean = false,
    val isLoading: Boolean = true
)

