package com.automationhub.data.database

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context
import com.automationhub.data.database.dao.NoteDao
import com.automationhub.data.database.dao.ProgressDao
import com.automationhub.data.database.entity.NoteEntity
import com.automationhub.data.database.entity.ProgressEntity

/**
 * Room database for the Automation Hub app
 */
@Database(
    entities = [NoteEntity::class, ProgressEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    
    abstract fun noteDao(): NoteDao
    abstract fun progressDao(): ProgressDao
    
    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null
        
        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "automation_hub_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

