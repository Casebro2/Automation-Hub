package com.automationhub.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.automationhub.data.model.Module
import com.automationhub.data.repository.AutomationHubRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel for the Modules screen
 */
class ModulesViewModel(private val repository: AutomationHubRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(ModulesUiState())
    val uiState: StateFlow<ModulesUiState> = _uiState.asStateFlow()

    init {
        loadModules()
    }

    private fun loadModules() {
        viewModelScope.launch {
            val modules = repository.getModules()
            _uiState.value = _uiState.value.copy(
                modules = modules,
                isLoading = false
            )
        }
    }

    fun filterByStage(stage: String) {
        val allModules = repository.getModules()
        val filteredModules = if (stage == "All") {
            allModules
        } else {
            allModules.filter { it.stage == stage }
        }
        _uiState.value = _uiState.value.copy(
            modules = filteredModules,
            selectedStage = stage
        )
    }
}

data class ModulesUiState(
    val modules: List<Module> = emptyList(),
    val selectedStage: String = "All",
    val isLoading: Boolean = true
)

