package com.automationhub.data.repository

import android.content.Context
import com.automationhub.data.database.AppDatabase
import com.automationhub.data.database.entity.NoteEntity
import com.automationhub.data.database.entity.ProgressEntity
import com.automationhub.data.model.Module
import com.automationhub.data.model.Project
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.json.Json
import java.io.IOException

/**
 * Repository for managing data related to modules, projects, notes, and progress.
 */
class AutomationHubRepository(private val context: Context) {

    private val noteDao = AppDatabase.getDatabase(context).noteDao()
    private val progressDao = AppDatabase.getDatabase(context).progressDao()

    //region Modules and Projects (from assets)
    private val json = Json { ignoreUnknownKeys = true }

    private fun loadJsonFromAsset(fileName: String): String {
        return try {
            context.assets.open(fileName).bufferedReader().use { it.readText() }
        } catch (ioException: IOException) {
            ioException.printStackTrace()
            ""
        }
    }

    fun getModules(): List<Module> {
        val jsonString = loadJsonFromAsset("modules.json")
        return if (jsonString.isNotEmpty()) {
            json.decodeFromString<List<Module>>(jsonString)
        } else {
            emptyList()
        }
    }

    fun getProjects(): List<Project> {
        val jsonString = loadJsonFromAsset("projects.json")
        return if (jsonString.isNotEmpty()) {
            json.decodeFromString<List<Project>>(jsonString)
        } else {
            emptyList()
        }
    }

    fun getModuleById(moduleId: String): Module? {
        return getModules().find { it.id == moduleId }
    }

    fun getProjectById(projectId: String): Project? {
        return getProjects().find { it.id == projectId }
    }
    //endregion

    //region Notes
    fun getNotesForLesson(lessonId: String): Flow<List<NoteEntity>> {
        return noteDao.getNotesForLesson(lessonId)
    }

    fun getAllNotes(): Flow<List<NoteEntity>> {
        return noteDao.getAllNotes()
    }

    suspend fun insertNote(note: NoteEntity) {
        noteDao.insertNote(note)
    }

    suspend fun updateNote(note: NoteEntity) {
        noteDao.updateNote(note)
    }

    suspend fun deleteNote(note: NoteEntity) {
        noteDao.deleteNote(note)
    }

    suspend fun deleteNotesForLesson(lessonId: String) {
        noteDao.deleteNotesForLesson(lessonId)
    }
    //endregion

    //region Progress
    fun getProgressForModule(moduleId: String): Flow<List<ProgressEntity>> {
        return progressDao.getProgressForModule(moduleId)
    }

    suspend fun getProgressForLesson(lessonId: String): ProgressEntity? {
        return progressDao.getProgressForLesson(lessonId)
    }

    suspend fun getProgressForProject(projectId: String): ProgressEntity? {
        return progressDao.getProgressForProject(projectId)
    }

    fun getCompletedItems(): Flow<List<ProgressEntity>> {
        return progressDao.getCompletedItems()
    }

    suspend fun insertProgress(progress: ProgressEntity) {
        progressDao.insertProgress(progress)
    }

    suspend fun updateProgress(progress: ProgressEntity) {
        progressDao.updateProgress(progress)
    }

    suspend fun getCompletedCount(): Int {
        return progressDao.getCompletedCount()
    }

    suspend fun getTotalCount(): Int {
        return progressDao.getTotalCount()
    }
    //endregion
}

