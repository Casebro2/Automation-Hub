package com.automationhub.navigation

/**
 * Sealed class to define all screens and their routes in the application.
 */
sealed class Screen(val route: String) {
    object Onboarding : Screen("onboarding")
    object Dashboard : Screen("dashboard")
    object Modules : Screen("modules")
    object ModuleDetail : Screen("module_detail/{moduleId}") {
        fun createRoute(moduleId: String) = "module_detail/$moduleId"
    }
    object LessonDetail : Screen("lesson_detail/{moduleId}/{lessonId}") {
        fun createRoute(moduleId: String, lessonId: String) = "lesson_detail/$moduleId/$lessonId"
    }
    object Projects : Screen("projects")
    object ProjectDetail : Screen("project_detail/{projectId}") {
        fun createRoute(projectId: String) = "project_detail/$projectId"
    }
    object Calendar : Screen("calendar")
    object Notes : Screen("notes")
    object Settings : Screen("settings")
}

