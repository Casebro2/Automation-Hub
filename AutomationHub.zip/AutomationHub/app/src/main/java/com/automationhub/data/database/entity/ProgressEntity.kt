package com.automationhub.data.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room entity for tracking user progress
 */
@Entity(tableName = "progress")
data class ProgressEntity(
    @PrimaryKey val id: String,
    val moduleId: String,
    val lessonId: String? = null,
    val projectId: String? = null,
    val isCompleted: Boolean = false,
    val completionDate: Long? = null,
    val progressPercentage: Int = 0
)

