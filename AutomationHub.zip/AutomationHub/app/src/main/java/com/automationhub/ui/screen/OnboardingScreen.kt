package com.automationhub.ui.screen

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.automationhub.R
import kotlinx.coroutines.launch

/**
 * Onboarding screen with introductory slides.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(onNavigateToDashboard: () -> Unit) {
    val pages = listOf(
        OnboardingPage(
            title = "Welcome to Automation Hub!",
            description = "Your journey to mastering automation starts here. Learn no-code and code-based workflows.",
            imageRes = R.drawable.ic_onboarding_welcome
        ),
        OnboardingPage(
            title = "Beginner to Expert",
            description = "Progress through structured modules from foundational concepts to advanced AI workflows.",
            imageRes = R.drawable.ic_onboarding_progress
        ),
        OnboardingPage(
            title = "Hands-on Projects",
            description = "Apply your knowledge with practical projects using tools like n8n, Zapier, Python, and JS.",
            imageRes = R.drawable.ic_onboarding_projects
        )
    )
    val pagerState = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        HorizontalPager(state = pagerState, modifier = Modifier.weight(1f)) {
            page ->
            OnboardingPageContent(pages[page])
        }

        Row(
            Modifier
                .wrapContentHeight()
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            repeat(pagerState.pageCount) {
                iteration ->
                val color = if (pagerState.currentPage == iteration) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
                Text(
                    text = "•",
                    modifier = Modifier.padding(horizontal = 4.dp),
                    color = color,
                    fontSize = 24.sp
                )
            }
        }

        Button(
            onClick = {
                if (pagerState.currentPage < pages.size - 1) {
                    scope.launch {
                        pagerState.animateScrollToPage(pagerState.currentPage + 1)
                    }
                } else {
                    onNavigateToDashboard()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 32.dp, vertical = 16.dp)
        ) {
            Text(text = if (pagerState.currentPage < pages.size - 1) "Next" else "Get Started")
        }
    }
}

@Composable
fun OnboardingPageContent(page: OnboardingPage) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = page.imageRes),
            contentDescription = null,
            modifier = Modifier.size(200.dp)
        )
        Spacer(modifier = Modifier.height(32.dp))
        Text(
            text = page.title,
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = page.description,
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

data class OnboardingPage(
    val title: String,
    val description: String,
    val imageRes: Int
)


