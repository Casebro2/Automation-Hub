package com.automationhub.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.automationhub.data.repository.AutomationHubRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel for the Dashboard screen
 */
class DashboardViewModel(private val repository: AutomationHubRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        loadDashboardData()
    }

    private fun loadDashboardData() {
        viewModelScope.launch {
            val modules = repository.getModules()
            val projects = repository.getProjects()
            val completedCount = repository.getCompletedCount()
            val totalCount = repository.getTotalCount()

            _uiState.value = _uiState.value.copy(
                modules = modules,
                projects = projects,
                completedCount = completedCount,
                totalCount = totalCount,
                progressPercentage = if (totalCount > 0) (completedCount * 100) / totalCount else 0,
                isLoading = false
            )
        }
    }

    fun refreshData() {
        _uiState.value = _uiState.value.copy(isLoading = true)
        loadDashboardData()
    }
}

data class DashboardUiState(
    val modules: List<com.automationhub.data.model.Module> = emptyList(),
    val projects: List<com.automationhub.data.model.Project> = emptyList(),
    val completedCount: Int = 0,
    val totalCount: Int = 0,
    val progressPercentage: Int = 0,
    val isLoading: Boolean = true
)

