package com.automationhub.ui.viewmodel

import com.automationhub.data.model.Module
import com.automationhub.data.model.Project
import com.automationhub.data.repository.AutomationHubRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.mockito.Mockito.mock
import org.mockito.Mockito.`when`

@ExperimentalCoroutinesApi
class DashboardViewModelTest {

    private lateinit var repository: AutomationHubRepository
    private lateinit var viewModel: DashboardViewModel
    private val testDispatcher = UnconfinedTestDispatcher()

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        repository = mock(AutomationHubRepository::class.java)
    }

    @Test
    fun `uiState is initialized with correct data`() = runTest {
        // Given
        val mockModules = listOf(Module("m1", "Module 1", "Desc 1", "Beginner", emptyList()))
        val mockProjects = listOf(Project("p1", "Project 1", "Desc 1", "Easy", emptyList(), emptyList(), "1hr"))
        `when`(repository.getModules()).thenReturn(mockModules)
        `when`(repository.getProjects()).thenReturn(mockProjects)
        `when`(repository.getCompletedCount()).thenReturn(5)
        `when`(repository.getTotalCount()).thenReturn(10)

        // When
        viewModel = DashboardViewModel(repository)

        // Then
        val uiState = viewModel.uiState.first()
        assertEquals(mockModules, uiState.modules)
        assertEquals(mockProjects, uiState.projects)
        assertEquals(5, uiState.completedCount)
        assertEquals(10, uiState.totalCount)
        assertEquals(50, uiState.progressPercentage)
        assertEquals(false, uiState.isLoading)
    }

    @Test
    fun `refreshData updates uiState`() = runTest {
        // Given
        `when`(repository.getModules()).thenReturn(emptyList())
        `when`(repository.getProjects()).thenReturn(emptyList())
        `when`(repository.getCompletedCount()).thenReturn(0)
        `when`(repository.getTotalCount()).thenReturn(0)
        viewModel = DashboardViewModel(repository)

        val newModules = listOf(Module("m2", "Module 2", "Desc 2", "Intermediate", emptyList()))
        val newProjects = listOf(Project("p2", "Project 2", "Desc 2", "Medium", emptyList(), emptyList(), "2hr"))
        `when`(repository.getModules()).thenReturn(newModules)
        `when`(repository.getProjects()).thenReturn(newProjects)
        `when`(repository.getCompletedCount()).thenReturn(1)
        `when`(repository.getTotalCount()).thenReturn(2)

        // When
        viewModel.refreshData()

        // Then
        val uiState = viewModel.uiState.first()
        assertEquals(newModules, uiState.modules)
        assertEquals(newProjects, uiState.projects)
        assertEquals(1, uiState.completedCount)
        assertEquals(2, uiState.totalCount)
        assertEquals(50, uiState.progressPercentage)
        assertEquals(false, uiState.isLoading)
    }
}

