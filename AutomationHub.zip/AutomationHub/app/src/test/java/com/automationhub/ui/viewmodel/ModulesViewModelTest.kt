package com.automationhub.ui.viewmodel

import com.automationhub.data.model.Module
import com.automationhub.data.repository.AutomationHubRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.mockito.Mockito.mock
import org.mockito.Mockito.`when`

@ExperimentalCoroutinesApi
class ModulesViewModelTest {

    private lateinit var repository: AutomationHubRepository
    private lateinit var viewModel: ModulesViewModel
    private val testDispatcher = UnconfinedTestDispatcher()

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        repository = mock(AutomationHubRepository::class.java)
    }

    @Test
    fun `filterByStage filters modules correctly`() = runTest {
        // Given
        val modules = listOf(
            Module("m1", "Module 1", "Desc 1", "Beginner", emptyList()),
            Module("m2", "Module 2", "Desc 2", "Intermediate", emptyList()),
            Module("m3", "Module 3", "Desc 3", "Beginner", emptyList())
        )
        `when`(repository.getModules()).thenReturn(modules)
        viewModel = ModulesViewModel(repository)

        // When
        viewModel.filterByStage("Beginner")

        // Then
        val uiState = viewModel.uiState.first()
        assertEquals(2, uiState.modules.size)
        assertEquals("Beginner", uiState.selectedStage)
        assertEquals("Beginner", uiState.modules[0].stage)
        assertEquals("Beginner", uiState.modules[1].stage)
    }

    @Test
    fun `filterByStage with All shows all modules`() = runTest {
        // Given
        val modules = listOf(
            Module("m1", "Module 1", "Desc 1", "Beginner", emptyList()),
            Module("m2", "Module 2", "Desc 2", "Intermediate", emptyList())
        )
        `when`(repository.getModules()).thenReturn(modules)
        viewModel = ModulesViewModel(repository)

        // When
        viewModel.filterByStage("All")

        // Then
        val uiState = viewModel.uiState.first()
        assertEquals(2, uiState.modules.size)
        assertEquals("All", uiState.selectedStage)
    }
}

